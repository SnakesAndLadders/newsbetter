# NewsBetter
## Reason
Most rss readers use the contents of the RSS feed to display their data. Many RSS providers lately have been adding very little text to the body of the feed file in order to encourage you to click on the link to go to the article. I made this software using [Newspaper3k](https://newspaper.readthedocs.io/en/latest/) to grab the body of the article text and display in the TUI so you don't have to take that extra step! 
