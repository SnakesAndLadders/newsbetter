import NewsBetter

NewsBetter.main()
